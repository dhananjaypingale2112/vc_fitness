<?php 
  $data['page'] = "";
  $this->load->view('templates/header',$data);
?> 
            <!-- header-wrapper ends here -->
            <div id="main">
                <!-- main-content starts here -->
                <div id="main-content">
                    <section id="primary" class="content-full-width">
                       
                    </section>
				</div>
			</div>
            <div id="main">
                <!-- main-content starts here -->
                <div id="main-content">
                    <section id="primary" class="content-full-width">
                        <div class="dt-sc-hr-invisible"></div>
                        <div class="dt-sc-hr-invisible"></div>
                        <div class="fullwidth-section dt-sc-paralax">
                            <div class="container">
                                <div class="dt-sc-three-fourth column first animate" data-animation="fadeInUp" data-delay="100">
                                    <h4 class="section-title">Your order has been placed!</h4>
                                    <p class="text-justify">Your order has been successfully processed!

									You can view your order history by going to the my account page and by clicking on history.

									If your purchase has an associated download, you can go to the account downloads page to view them.

									Please direct any questions you have to the store owner.

									Thanks for shopping with us online!</p>

								</div>
                            </div>
                        </div>
                    </section>
				</div>
			</div>
                		
<?php 
  $this->load->view('templates/footer')
?>