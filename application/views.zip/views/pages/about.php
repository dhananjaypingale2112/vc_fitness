<?php 
    $data['page'] = "aboutUs";
  $this->load->view('templates/header',$data)
?> 
            <!-- header-wrapper ends here -->
            
            <div id="main">
                <!-- main-content starts here -->
                <div id="main-content">
                    <section id="primary" class="content-full-width">
                        <div class="dt-sc-hr-invisible"></div>
                        <div class="dt-sc-hr-invisible"></div>
                        <div class="fullwidth-section dt-sc-paralax">
                            <div class="container">
                                <div class="dt-sc-three-fourth column first animate" data-animation="fadeInUp" data-delay="100">
                                    <h4 class="section-title">My Journey</h4>
                                    <p class="text-justify">I would like to share my journey from a middle class family, one normal guy to a professional Bodybuilder to India's no. 1 celebrity trainer and Fitness expert.</p>

<p class="text-justify">From my childhood till my college time I was very thin and underweight kid in the family. All friends and relatives used to tease me as 'Sukda' means very thin guy. But in my father's limited salary we could not afford to have even one time milk. Sometimes we had to be satisfied only on a one meal in a day. I was fed up with the people's comments that I don't have good physique. In that aggression I had decided towork on my body. Due to financial problems I was not able to join any standard gym. That time I started working along with my college studies because there was no financial support.</p>

<a onclick ="javascript:ShowHide('HiddenDiv')" href="javascript:;" >Read More....</a>
<div class="mid" id="HiddenDiv" style="DISPLAY: none" >
<p class="text-justify">I have worked for corporate as well as government firms. But I was not happy working there, and could manage to work only for 2 to 3 months as I was very much passionate about Fitness. From my salary 1/4 part I used to give it at home and rest I keep it for myself. Family members were upset and angry on me, being elder in the family I was not giving sufficient amount to run the family. I did not had any other option. I thought if I help myself now, I will be able to take care of my family in future.</p>

<p class="text-justify">I wanted to make my career in fitness and wanted to be recognised by the world's Top rated personal trainer. I could manage to go to the local gym which was nearer to my house. Monthly I used to pay 50/- Rs as I could not afford to join any other standard gyms. I have implemented all different types of workout routines and diets to know how the body reacts from one change to another.</p>

<p class="text-justify">I started my bodybuilding profession and side by side I was working as Personal Trainer. I was certified by k-11 academy. I have won many titles like : Mr. Mumbai Gold Medal 2008, Mr. Mumbai Silver Medal - 2 times, Mr. Maharashtra Silver Medal - 2 times, Novoice Mr. Mumbai Champion of champion, Mr. Jogeshwari Champion of champion, Mr. Girgaon Champion of champion, Kamgar Shree Champion of champion, R. M. Bhat college Champion of champion. I have worked for Talwalkar as Personal Trainer.</p>

<p class="text-justify">I have trained my body in difficult situations. That did not stop me from working. Soon after that I started working freelance Personal Trainer. From borivali to Neapeanse road I had my personal clients. From early morning till night, it rains or shine I worked very hard. After sometimes I started working freelance Personal Trainer in Sykz gym at Bandra.</p>

<p class="text-justify">I always believe in giving results to the people and because of my dedication one of my clients suggested my name to Ritesh deshmukh. After this there was no looking back. Ritesh deshmukh was very happy as he got good results for the movie houseful 1. I also trained all the co actors of Houseful-1.</p>

<p>After Ritesh I got opportunity to train Ashish Chudhary, John Abraham ( Force movie, Race-2, Shoot out at wadala), Genelia d'souza, Jiya khan, Sohail khan, Abhijit sawant ( 1st indian idol), Shekhar ( music director), Samita shetty, Shilpa shetty, Raj kundra, Harman baweja, Aayushman Khurana, R.Madhavan, Krishika lulla, Purna patel (daughter of mr. Praful patel), Smriti Shinde ( daughter of Home ministers mr. Sushilkumar shinde).</p>

<p class="text-justify">In my life I belive in hard work and giving results to the people. If you are good at something one should be dedicated and passionate about it. There will be lot of challenges but we should not lose hope. We should keep on trying until we get success. Keep on reading about fitness, latest workout trend in the market and accordingly keep updating youreself. Your knowledge only will take you to the higher level. Don't get demotivated if thing's does not work properly for you.</p>
</div>

  <p><em>'Perfect practice makes man Perfect'.</em></p>
                                </div>
                                <div class="dt-sc-one-fourth column animate" data-animation="fadeInLeft" data-delay="100">
                                	<!--<h4 class="section-title">Vinod Channa</h4>-->
                                    <h4 class="section-title text-center"><img src="<?php echo base_url();?>public/images/name.png"></h4>
                                     <img src="<?php echo base_url();?>public/images/vinod-chnna.jpg">
                                  </div>
                            </div>
						</div>
                		<!-- Events starts here -->
                        
                        <div class="dt-sc-hr-invisible-medium"></div>
                        
                        <div class="fullwidth-section">
                            <div class="container animate" data-animation="fadeInUp" data-delay="100">
                                <div class="dt-sc-tabs-container">
                                    <ul class="dt-sc-tabs-frame">
                                        <li><a href="#" class="current">Awards And Acheivements</a></li>
                                        <li><a href="#">Celebrity / Corporate Clients</a></li>
                                        <li><a href="#"> Videos </a></li>
                                    </ul>
                                    <div class="dt-sc-tabs-frame-content"> 
                                    	<div class="dt-sc-hr-invisible-small"></div>
                                        
                                        <div class="dt-sc-two-third column first">
                                             <div class="dt-sc-hr-invisible-small"></div>
                                            <p>                                   
                                             <div class="blog-post">
                                    	<div class="blog-post-inner">
                                        	<div class="blog-thumb">
                                            	<a href="#"><img src="<?php echo base_url();?>public/images/blog-thumbnail.jpg" alt="" title=""></a>
                                            </div>
                                            <div class="blog-detail">
                                            	<h2><a href="#">Mr.Mumbai Gold Medal</a></h2>
                                                <p>Sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi. </p>
                                            </div>
                                        </div>
                                        <ul class="blog-post-meta">
                                             <li><span class="fa fa-calendar"></span>2008</li>
                                          <!--  <li class="categories"><a href="#">sports</a></li>-->
                                        </ul>
                                    </div>
                                  			 <div class="blog-post">
                                    	<div class="blog-post-inner">
                                        	<div class="blog-thumb">
                                            	<a href="#"><img src="<?php echo base_url();?>public/images/blog-thumbnail.jpg" alt="" title=""></a>
                                            </div>
                                            <div class="blog-detail">
                                            	<h2><a href="#">Mr.Mumbai Sliver Medal</a></h2>
                                                <p>Sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi. </p>
                                            </div>
                                        </div>
                                        <ul class="blog-post-meta">
                                             <li><span class="fa fa-calendar"></span>2014</li>
                                            <li class="categories"><a href="#">2 times</a></li>
                                        </ul>
                                    </div> 
                                    </p>
                                          
                                        </div>
                                        <div class="dt-sc-one-third column">
                                              <div class="dt-sc-hr-invisible-small"></div>

                                         
            <!-- Carousel
            ================================================== -->
             
							  <div class="recommended_items"><!--recommended_items-->
 						<div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
							<div class="carousel-inner">
								<div class="item active">	
									<div class="col-sm-12">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="<?php echo base_url();?>public/images/award.jpg" alt="" />
													<h3>Celebrity Trainer of the Year</h3>
													<p>Vinod Channa is Mumbai based Personal Trainer with over 16 years of experience</p>
													<a href="#" class="dt-sc-button small" 
                                                    data-hover="Read More">
                                                     Read More</a>
                                                   
													
												</div>
												
											</div>
										</div>
									</div>
							 
								</div>
                                
								<div class="item">	
									<div class="col-sm-12">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="<?php echo base_url();?>public/images/award.jpg" alt="" />
													<h3>Celebrity Trainer of the Year</h3>
													<p>Vinod Channa is Mumbai based Personal Trainer with over 16 years of experience</p>
													<a href="#" class="dt-sc-button small"
                                                     data-hover="Read More"> 
                                                     Read More</a>
												</div>
												
											</div>
										</div>
									</div>
					 
								</div>
                                
                                
                                <div class="item">	
									<div class="col-sm-12">
										<div class="product-image-wrapper">
											<div class="single-products">
												<div class="productinfo text-center">
													<img src="<?php echo base_url();?>public/images/award.jpg" alt="" />
													<h3>Celebrity Trainer of the Year</h3>
													<p>Vinod Channa is Mumbai based Personal Trainer with over 16 years of experience</p>
													<a href="#" class="dt-sc-button small" 
                                                    data-hover="Read More">
                                                     Read More</a>
												</div>
												
											</div>
										</div>
									</div>
									 
								</div>
							</div>
							 <a class="left recommended-item-control" href="#recommended-item-carousel" data-slide="prev">
								<i class="fa fa-angle-left"></i>
							  </a>
							  <a class="right recommended-item-control" href="#recommended-item-carousel" data-slide="next">
								<i class="fa fa-angle-right"></i>
							  </a>			
						</div>
					</div>
                    
             <!-- End Carousel -->  
    	 
                                        </div>
                                    </div>
                                    <div class="dt-sc-tabs-frame-content"> 
                                    	<div class="dt-sc-hr-invisible-small"></div>
                                        <div class="dt-sc-one-half column first">
                                        
                                             <p>     
                                            <div class="column dt-sc-one-half first">
                                <div class="dt-sc-ico-content type8">
                                    <div class="icon-wrap">
                                        <div class="icon">
                                        <img src="<?php echo base_url();?>public/images/service-img1.png" alt="service-img1" title="">
                                        <div class="icon-overlay">
                                            <a href="#"><span class="fa fa-link"></span></a>
                                        </div>
                                    </div>
                                    </div>
                                    <h4>John Abrahim</h4>
                                    <span>I am thankful to Vinod not only for training...</span>
                                    <a href="#" class="dt-sc-button small" data-hover="Know More">Know More</a>
								</div>
                            </div>
                            <div class="column dt-sc-one-half">
                                <div class="dt-sc-ico-content type8">
                                    <div class="icon-wrap">
                                        <div class="icon">
                                            <img src="<?php echo base_url();?>public/images/service-img2.png" alt="service-img2" title="">
                                            <div class="icon-overlay">
                                                <a href="testimonials.html"><span class="fa fa-link"></span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <h4>Shilpa Shetty</h4>
                                    <span>lost 14kg of her post pregnancy weight...</span>
                                    <a href="testimonials.html" class="dt-sc-button small" data-hover="Know More">Know More</a>
                                </div>
                            </div> </p>
                                        </div>
                                        <div class="dt-sc-one-half column">
                                        <div class="list-wrpaaer" style="height:410px">
             <ul class="list-aggregate dt-sc-fancy-list circle-o custom-fancy-ico" id="marquee-vertical">
 
 
 <li class="news-item">
<table cellpadding="4">
<tr>
<td><img src="<?php echo base_url();?>public/images/team1.jpg" width="60" class="img-circle" /></td>
<td>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in venenatis enim...
	<a href="testimonials.html">Read more... </a></p>
</td>
</tr>
</table>
</li>

<li class="news-item">
<table cellpadding="4">
<tr>
<td><img src="<?php echo base_url();?>public/images/team2.jpg" width="60" class="img-circle" /></td>
<td>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in venenatis enim...
	<a href="testimonials.html">Read more... </a></p>
</td>
</tr>
</table>
</li>

<li class="news-item">
<table cellpadding="4">
<tr>
<td><img src="<?php echo base_url();?>public/images/team3.jpg" width="60" class="img-circle" /></td>
<td>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in venenatis enim... 
	<a href="testimonials.html">Read more... </a></p>
</td>
</tr>
</table>
</li>

<li class="news-item">
<table cellpadding="4">
<tr>
<td><img src="<?php echo base_url();?>public/images/team4.jpg" width="60" class="img-circle" /></td>
<td>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in venenatis enim... 
	<a href="testimonials.html">Read more... </a></p>
</td>
</tr>
</table>
</li>
<li class="news-item">
<table cellpadding="4">
<tr>
<td><img src="<?php echo base_url();?>public/images/team5.jpg" width="60" class="img-circle" /></td>
<td>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in venenatis enim... 
	<a href="testimonials.html">Read more... </a></p>
</td>
</tr>
</table>
</li>
<li class="news-item">
<table cellpadding="4">
<tr>
<td><img src="<?php echo base_url();?>public/images/team6.jpg" width="60" class="img-circle" /></td>
<td>
	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in venenatis enim... 
	<a href="testimonials.html">Read more... </a></p>
</td>
</tr>
</table>
</li>
 
 
            

             </ul>
          </div>
                                        
                                        </div>
                                    </div>
                                    <div class="dt-sc-tabs-frame-content"> 
                                    	<div class="dt-sc-hr-invisible-small"></div>
                                        <div class="dt-sc-one-column column first">
                                        	<!--<h2>Cras fringilla leo non quam placerat egestas?</h2>-->
                                            <div class="dt-sc-hr-invisible-small"></div>
                                            <p>	
                                            <div class="carousel slide media-carousel" id="media">
        <div class="carousel-inner video">
          <div class="item active">
            <div class="row">
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>          
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>        
            </div>
          </div>
          <div class="item">
            <div class="row">
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>          
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>        
            </div>
          </div>
          <div class="item">
            <div class="row">
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>          
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>
              <div class="col-md-4">
                <a class="thumbnail youtube-btn" href="http://www.youtube.com/watch?v=QgbpcsjvBks"><img alt="" src="<?php echo base_url();?>public/images/award.jpg"></a>
              </div>        
            </div>
          </div>
        </div>
        <a data-slide="prev" href="#media" class="left carousel-control">‹</a>
        <a data-slide="next" href="#media" class="right carousel-control">›</a>
      </div> </p>
                                        </div>
                                        <!--<div class="dt-sc-one-half column">
                                        	<ul class="dt-sc-fancy-list circle-o custom-fancy-ico">
                                                <li>
                                                	<h5>Improve your Diet</h5>
                                                    <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque. </p>
                                                </li>
                                                <li>
                                                	<h5>Stay Determined</h5>
                                                    <p>Corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident. </p>
                                                </li>
                                                <li>
                                                	<h5>Push your Limits</h5>
                                                    <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque. </p>
                                                </li>
                                            </ul>
                                        </div>-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Tabs ends here -->
                        
                        <div class="dt-sc-hr-invisible"></div>
 
                          
                        <!-- welcome-txt ends here -->
                        <div class="dt-sc-hr-invisible-large"></div>
                    </section>
				</div>
                <!-- main-content ends here -->
                
            </div>
<?php 
  $this->load->view('templates/footer')
?>